import java.util.Random;

public class ThreadClass implements Runnable {
    private Disco discoteca;
    private int tempo;
    private int persone;

    public void run() {
        while (true) {
            try {
                Random rand = new Random();
                tempo = rand.nextInt(100);


                discoteca.Entra(); //entro
                Thread.sleep(tempo);//aspetto, ma aspetto anche dopo
                discoteca.Esci();
                Thread.sleep(tempo);



            } catch (InterruptedException aaaa) {
                aaaa.printStackTrace();
            }
        }
    }


    ThreadClass(Disco discoteca) {
        this.discoteca = discoteca;
    }
}
