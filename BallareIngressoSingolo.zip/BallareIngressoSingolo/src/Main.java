import java.util.Random;
import java.util.Scanner;



public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("num persone: ");
        int t = input.nextInt();

        Disco discoteca = new Disco();
        for (int i = 0; i < t; i++) {
            ThreadClass andrea = new ThreadClass(discoteca);
            Thread thread = new Thread(andrea);
            thread.start();
        }



        int personeindisco;


        while(true){
            try{

                Thread.sleep(1000);
                personeindisco = discoteca.quantepersone();
                System.out.println("persone dentro: "+personeindisco);

            } catch (InterruptedException a) {
                a.printStackTrace();
            }
        }

    }
}