public class Disco {
    private int ptotali;

    public synchronized void Entra() {
        ptotali++;
    }

    public synchronized void Esci() {
        ptotali--;
    }

    public int quantepersone(){
        return ptotali;
    }


}

