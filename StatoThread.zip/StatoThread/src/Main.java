import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Numero di thread: ");
        int t = input.nextInt();

        System.out.print("Numero massimo: ");
        int n = input.nextInt();

        ThreadClass[] array = new ThreadClass[t];


        int valorethread;
        boolean tuttofinito = false;
        int conta=0;

        for(int i = 0; i<t; i++) {
            ThreadClass andrea = new ThreadClass(n);
            Thread thread = new Thread(andrea);
            thread.start();
            array[i] = andrea;
        }


        while(!tuttofinito) {
            for(int i = 0; i<t; i++){
                if(!array[i].getStato()) {
                    valorethread = array[i].getPunto();
                    System.out.println("Thread " + i + ": non pronto ---> ("+valorethread+")" );
                }else {
                    System.out.println("Thread " + i + " COMPLETATO");
                    conta++;
                }
            }

            if(conta == t) tuttofinito = true;
        }
        System.out.println("Tutti i thread sono stati completati");




    }
}
