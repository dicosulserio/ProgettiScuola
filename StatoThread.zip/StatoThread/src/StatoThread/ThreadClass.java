import java.util.Random;
public class ThreadClass implements Runnable{
    private int num;
    private int x;
    private boolean stato = false;
    private int achepuntosono;





    public void run(){
        Random rand = new Random();
        x = rand.nextInt(num + 1);


        for(int i=0; i<x; i++){
            try {
                Thread.sleep(120);   // sleep for 120 milliseconds
            } catch (InterruptedException e ) {}
            achepuntosono = i;
        }
        stato = true;
    }

    public boolean getStato(){
        return stato;
    }

    public int getPunto(){
        return achepuntosono;
    }

    ThreadClass(int num){
        this.num=num;

    }


}